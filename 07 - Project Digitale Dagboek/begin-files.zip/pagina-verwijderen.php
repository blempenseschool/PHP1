<?php 

include 'includes/config.inc'; // Include config bestand
$active = ''; // Welke is de huidige pagina aangeduid in de navbar?
$page_title = 'Mijn eerste dagboek pagina';
$body_class = 'concrete-bg';

beveilig_pagina();

